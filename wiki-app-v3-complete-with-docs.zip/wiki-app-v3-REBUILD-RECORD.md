# wiki-app-v2 → v3 Rebuild — Complete Project Record

> **Purpose:** This document is the authoritative record of the wiki-app-v2 rebuild project, written for an AI agent or developer picking up the codebase with no prior context. It covers what the app is, what was broken, what was fixed, why each decision was made, the current state of every feature, and what remains.

---

## Table of Contents

1. [What This App Is](#1-what-this-app-is)
2. [Repository Structure](#2-repository-structure)
3. [The Problem We Found](#3-the-problem-we-found)
4. [What We Changed — Phase by Phase](#4-what-we-changed--phase-by-phase)
5. [Current Feature Status](#5-current-feature-status)
6. [Architecture Decisions](#6-architecture-decisions)
7. [Security Posture](#7-security-posture)
8. [Test Coverage](#8-test-coverage)
9. [Known Issues & Limitations](#9-known-issues--limitations)
10. [What Needs To Be Done](#10-what-needs-to-be-done)
11. [How To Run](#11-how-to-run)
12. [Key Files Reference](#12-key-files-reference)

---

## 1. What This App Is

**wiki-app-v2** is a personal knowledge-base / wiki application in the spirit of Trilium Notes — hierarchical (spaces → pages → branches) AND cross-linked (wikilinks, backlinks, typed relations, graph view). It is designed for a homelab operator: someone running a Proxmox cluster, ham radio notes, recipes, Linux reference docs, etc. on their own hardware.

### Core capabilities

- **Rich text editor** built on TipTap 3 (ProseMirror) with real-time collaboration via Hocuspocus + Yjs
- **Page tree** with react-arborist (spaces contain pages, pages can be cloned into multiple spaces with independent permission contexts)
- **Permission system** — a single `resolveAccess()` algorithm walks branch chains nearest-first, checking visibility, local group-permission boundaries, and space roles. Every route declares its access contract at registration time; the server refuses to boot if any route is missing it.
- **Plugin engine** — real manifest-validated, capability-gated, failure-isolated plugin system. Admins upload `.zip` files; plugins declare what they can do (tiptap extensions, slash commands, toolbar items, settings panels, embed types, server routes, hooks). A per-plugin consecutive-failure counter auto-disables misbehaving plugins.
- **Git-backed content store** — every page save is committed to a local git repo as Markdown (with YAML frontmatter). Snapshots, push/pull to remote, and DB snapshot/restore are all built in.
- **Knowledge-base-depth features** (brief §13): typed relations, graph view, template inheritance, attribute-driven table/board views (lenses), plugin event hooks, code pages, Mermaid diagrams, per-page encryption (AES-GCM envelope with DEK + KEK).
- **Offline support** — service worker caches pinned pages for read-only offline access.
- **PWA** — installable with manifest + icons.

### Tech stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Frontend framework | React | 19.2 |
| Router | TanStack Router | ^1.170 |
| Editor | TipTap (ProseMirror) | 3.29.2 |
| Styling | Tailwind CSS 4 + design tokens | 4.3.3 |
| Backend | Fastify | 5.11.2 |
| ORM | Drizzle (SQLite) | 0.45.2 |
| Database | better-sqlite3 | 12.11.1 |
| Auth | better-auth | 1.6.26 |
| Real-time | Hocuspocus + Yjs | 4.6.0 / 13.6.32 |
| Git ops | simple-git | 3.36.0 |
| Build | Vite | 8.2.1 |
| Tests | Vitest + Playwright | 4.1.10 / 1.62.1 |
| Language | TypeScript (strict) | 5.9.3 |

### Single-process architecture

The entire app runs in one Node.js process: Fastify HTTP server, Hocuspocus WebSocket collaboration, background job queue worker, and the debug-capture ring buffer. There is no Redis, no separate worker process, no external search index. This is deliberate — the brief explicitly scopes this as a single-tenant personal app, not a multi-instance SaaS.

---

## 2. Repository Structure

```
wiki-main/
├── wiki-app/              # V14 legacy codebase (FROZEN — do not touch)
├── wiki-app-v2/           # V2 rebuild (the active codebase, all work is here)
├── REBUILD.md             # Original rebuild narrative (slices 1-48)
├── AGENTS.md              # Cross-session memory for AI agents
├── WIKI-REDESIGN-BRIEF-V2.md  # The normative spec (768 lines)
├── bugfixes-and-search.patch  # V14 bugfixes (fully ported to V2)
└── .gitignore
```

### Branch structure

- `rebuild-v2` — the base branch (V2 codebase as it was before our work)
- `wiki-app-v3-rebuild` — **our branch** (rebuild-v2 + all Phase 0-4 changes). This is where all the work lives.

---

## 3. The Problem We Found

### The original rebuild was incomplete

The V2 rebuild (documented in `REBUILD.md`) shipped 48 slices and claimed feature completeness against the brief. However, a deep code analysis revealed:

1. **Three Critical spec-drift items** — features the brief mandated or V14 had, silently dropped from V2 without acknowledgement in REBUILD.md §7:
   - MCP server (JSON-RPC endpoint for AI agents) — brief §2 explicitly lists it in the "Keep" column
   - Public share-link viewer — server creates share URLs but no client route consumes them
   - Email delivery — no `nodemailer`, no mailer service, but a stale audit comment still claims "default delivery is email only"

2. **Ten High-severity issues** — missing security hardening, missing DB indexes, no ErrorBoundary, no encrypted secrets at rest, etc.

3. **Eight editor capabilities dropped from V14** — task lists, text alignment, smart quotes, highlight mark, @mentions, wikilinks, rich attachments, find & replace

4. **Four built-but-unwired features** — server code existed and tested green, but no UI consumed them: search, create-space, git-health-depth, audit-log

### A second audit (Claude AI) confirmed and expanded the list

A separate manual file-by-file comparison between V14 and V2 (documented in `PARITY-RESTORATION-PLAN.md`, not included in this repo but discussed extensively) found additional gaps the first scan missed: user-deletion content reassignment, encrypted-at-rest for system secrets, in-page find & replace, wikilink autocomplete, and rich attachment nodes.

### Root cause

The parity gap happened because of a **verification failure, not a coding failure**. The brief's §9.4 mandated "simulate real usage" but this wasn't followed. 619 tests passed while the UI for several features was never wired. API-level tests stood in for UI-level tests, and the gap wasn't caught until manual click-through.

---

## 4. What We Changed — Phase by Phase

### Phase 0 — Stop the bleeding (security hardening)

Five critical security fixes, each independently testable:

| # | Change | File(s) | Why |
|---|--------|---------|-----|
| 0.1 | **Fail-closed `BETTER_AUTH_SECRET`** | `src/server/auth/config.ts` | The auth secret had a hardcoded dev fallback (`dev-only-better-auth-secret-change-me-...`). A production deployment forgetting to set the env var would silently boot with a publicly-known secret, allowing session cookie forgery. Now throws at boot in production. |
| 0.2 | **Path-traversal guard** | `src/server/services/git.service.ts` | `commitPageChange` and `commitManualSnapshot` build filesystem paths from user-controlled space names. The slug regex already blocks `..`, but a regression in `slugify()` would create a path-traversal write. Added `assertInsideRepo()` that checks `resolved.startsWith(REPO_ROOT + path.sep)`. |
| 0.3 | **Root-level ErrorBoundary** | `src/routes/__root.tsx` | No `ErrorBoundary` existed anywhere. A render-time throw in any route component would white-screen the entire app. Added a class-component boundary with a styled fallback + reload button. |
| 0.4 | **15 missing DB indexes** | `src/server/db/schema.ts` + `drizzle/0011_missing_indexes.sql` | SQLite doesn't auto-index FK columns. `branches.spaceId`, `branches.pageId`, `attributes.pageId`, `backlinks.*`, `job_queue.status`, `comment_threads.pageId`, `comments.threadId`, `files.pageId`, `notifications.userId`, `favorites.userId`, `pinned_pages.userId`, `tokens.scopeId`, `tokens.createdBy` — all queried heavily, all were full table scans. |
| 0.5 | **Encrypted-at-rest for system secrets** | `src/server/services/crypto.service.ts` (new) + `src/server/routes/settings.routes.ts` | V14 had a `crypto.service.ts` that encrypted `system_settings` secrets (SMTP passwords, OAuth client secrets) with AES-256-GCM. V2 had no equivalent — secrets sat in plaintext. Ported the service, wired it into `setSystemSetting` (encrypt on write when `isSecret=true`) and added `getSystemSettingSecret` (decrypt on read). Boot-time `assertEncryptionKeyConfigured()` fails fast in production if `SETTINGS_ENCRYPTION_KEY` is unset. |

### Phase 0 — Process changes

| # | Change | File(s) | Why |
|---|--------|---------|-----|
| 0.6 | **CONTRIBUTING.md** | `CONTRIBUTING.md` (new) | The standing rule: no feature is "done" without (a) a Playwright e2e test AND (b) manual click-through. This is the rule that should have prevented the parity gap. |
| 0.7 | **Parity audit script** | `scripts/parity-audit.ts` (new) | Automated V14-vs-V2 diff. Compares route files, service files, client feature folders. Prints a gap report, exits 1 on unacknowledged gaps. Run: `npx tsx scripts/parity-audit.ts` |

### Phase 0 — Quick wins

| # | Change | File(s) | Why |
|---|--------|---------|-----|
| 0.8 | **PWA icons** | `public/icon.svg` (new), `public/manifest.webmanifest` | Manifest had `icons: []`. Installs fell back to a generic browser icon. |
| 0.9 | **Image width/height attrs** | `src/features/editor/extensions/image.ts` | Prevents cumulative layout shift (CLS) on image-heavy pages. |
| 0.10 | **Per-token rate limiter** | `src/server/middleware/access.ts` | Share-link password brute-force was per-IP only (10 attempts / 5 min). A botnet rotating IPs had no per-token cap. Added `SHARE_LINK_TOKEN_LIMITER` (50 attempts / hour per token). |
| 0.11 | **Lazy prismjs** | `src/features/editor/codeHighlight.ts`, `src/features/editor/useHighlightedCode.ts` (new) | Prism core + every language grammar was synchronously `require()`'d into the main bundle (~200KB). Refactored to dynamic `import()` with per-language caching. |

### Phase 1 — Reconnect built-but-unwired UI

| # | Feature | What existed | What was missing | What we built |
|---|---------|-------------|-----------------|---------------|
| 1.1 | Tree context menu | Server routes + e2e spec | Nothing — was already wired | Verified working |
| 1.2 | Search UI | `/api/search` endpoint + XSS regression test | No UI consumed it | `CommandPalette.tsx` — Cmd/Ctrl+K overlay, 200ms debounce, results grouped by space, keyboard nav, accessible |
| 1.3 | Create Space | `api.createSpace()` wrapper | No UI button | "Space" button in Tree sidebar + inline dialog (replaces `window.prompt`) |
| 1.4 | Git repo health | `/api/git/status`, `/log`, `/snapshots`, `/gc`, `/push`, `/pull` | Settings → System only showed last-flush-time | Full Git section: branch, dirty count, remote, last sync, snapshots, admin action buttons (snapshot/push/pull/gc), recent commits list |
| 1.5 | Audit Log | `audit_log` table written to by plugin/user/group/token routes | No read endpoint | `GET /api/settings/audit-log` (admin-only, joins users for actor name/email) + AuditLogSection component in Settings → System |

### Phase 2 — Restore editor capabilities from V14

All eight V14 editor features that were dropped from V2, restored:

| # | Feature | TipTap package | How it's wired |
|---|---------|---------------|----------------|
| 2.1 | Task lists / checkboxes | `@tiptap/extension-task-list` + `task-item` | Toolbar button + slash command |
| 2.2 | Text alignment | `@tiptap/extension-text-align` | 4 toolbar buttons (left/center/right/justify) |
| 2.3 | Typography (smart quotes) | `@tiptap/extension-typography` | Automatic — no UI needed |
| 2.4 | Highlight mark | `@tiptap/extension-highlight` | Toolbar button |
| 2.5 | @Mentions | `@tiptap/extension-mention` | `mentionExtension.tsx` — pure-DOM suggestion popup, `GET /api/users/mentionable` endpoint (cross-space spam prevention) |
| 2.6 | Internal wikilinks `[[Page]]` | Custom `Wikilink` Mark | `wikilink.ts` — `data-branch-id` attr, renders as `<a data-wikilink>` with dashed underline |
| 2.7 | Rich attachment node | Custom `Attachment` Node | `attachmentExtension.tsx` — ReactNodeViewRenderer, per-type icon (FileText/FileCode/FileImage/FileArchive/FileVideo/FileAudio), filename, size, download button. Non-image file uploads now insert attachment nodes instead of bare text links. |
| 2.8 | Find & replace | Custom `SearchReplacePopup` | `SearchReplacePopup.tsx` — Ctrl/Cmd+F popup, walks doc text for matches, prev/next nav, replace current / replace all |

### Phase 3 — Rebuild missing systems

| # | System | What V14 had | What V2 had | What we built |
|---|--------|-------------|------------|---------------|
| 3.1 | MCP server | 286-line JSON-RPC handler | Zero (silently dropped) | `mcp.routes.ts` — JSON-RPC 2.0 endpoint with 5 tools (list_spaces, get_page, search_pages, create_page, get_page_tree). Permission-filtered via `resolveAccess`. 8 integration tests. |
| 3.2 | Public share-link viewer | `PublicView.tsx` + `public.routes.ts` | Server creates `/?shareToken=...` URLs but `_authenticated.tsx` redirects to /login | `src/routes/_public/share.$branchId.tsx` — public route that consumes `shareToken` + `sharePassword` query params. Password prompt for protected links, read-only page view for unlocked. Updated `share.routes.ts` to return `/share/$branchId?shareToken=...` URL format. |
| 3.3 | Export / import | `export.service.ts` + `zip.service.ts` + `export.routes.ts` | Nothing | `export.service.ts` — `exportBranch()` + `exportSpace()` using `fflate` for zipping, `exportMarkdown` with `imageMode: "copy"` for asset bundling. `export.routes.ts` — `GET /api/branches/:branchId/export?format=zip|markdown` + `GET /api/spaces/:spaceId/export?format=zip` |
| 3.4 | Instance-to-instance sync | `sync.routes.ts` | Nothing (depends on MCP) | `sync.routes.ts` — `POST /api/sync/push` (admin-only). Uses MCP as transport: lists remote spaces, finds/creates matching space, pushes each page via `create_page` tool. |
| 3.5 | Email / mailer | `nodemailer` + `mailer.service.ts` + SMTP settings | Nothing | `mailer.service.ts` — `sendMail()`, `sendShareLinkWarning()`, `sendMentionNotification()`. SMTP config in `system_settings` (password encrypted at rest via §0.5). SMTP section in Settings → Integrations. |
| 3.6 | User-deletion content reassignment | `user-delete.service.ts` | Nothing — deleting a user left orphaned FK references | `user-delete.service.ts` — `reassignUserContent()` (transfer all artifacts to another user) + `deleteUserContent()` (permanently remove, spaces kept + handed to fallback). `DELETE /api/users/:id` admin endpoint with `?mode=reassign|delete`, last-admin guard, self-deletion block, audit log entry. |

### Phase 4 — Polish

| # | Change | File(s) | Impact |
|---|--------|---------|--------|
| 4.1 | Comment hover bubble | `CommentHoverBubble.tsx` (new) | Hovering over commented text shows a rich popup with the first comment's body, author, reply count, and resolved status. Click opens the full comments panel. |
| 4.2 | Editor width at startup | `useEditorWidthLoader.ts` (new) + `_authenticated.tsx` | The saved `editor.width` preference was only applied when the Appearance settings page was mounted. Now loaded at app startup via `useEditorWidthLoader()` hook in the `_authenticated` layout. |
| 4.3 | Typed Fastify decorator | `src/server/types/fastify.d.ts` (new) | Eliminates the `(request as any).userContext` cast pattern. Declares `userContext`, `principalKind`, `tokenScope`, `resolvedAccess`, `resolvedSpaceRole`, `branchChain` on `FastifyRequest`. New code can use `request.userContext` directly. |
| 4.4 | Replace native `confirm()` | `HistoryPanel.tsx`, `tokens.tsx`, `plugins.tsx` | Three native `window.confirm()` calls replaced with the accessible `ConfirmDialog` component (native `<dialog>` element, focus trap, Esc-to-close, backdrop click). |
| 4.5 | LRU eviction for Yjs doc cache | `collab.service.ts` | The `docs: Map<string, Doc>` cache was never cleared — grew without bound for the process lifetime. Added `MAX_DOCS = 50`, `touchDoc()` for LRU ordering, `evictIfNeeded()` that persists evicted docs to `collab_documents` before removal. |
| 4.6 | React.lazy for side panels | `$branchId.tsx` | CommentsPanel, HistoryPanel, RelationsPanel, GraphPanel were eagerly imported. Converted to `lazy()` + `Suspense` — a user who only reads pages never downloads the comments/history/relations/graph code. |

---

## 5. Current Feature Status

### ✅ Fully implemented and tested

- Spaces (create, list, tree, permissions, default role)
- Pages (create, edit, OCC save, soft-delete, restore, purge, rename + redirect)
- Branches (clone, move, delete, cycle guard)
- Rich text editor (TipTap 3 with StarterKit + 10 extensions)
- Task lists, text alignment, typography, highlight, mentions, wikilinks, attachments
- Find & replace (Ctrl+F)
- Real-time collaboration (Hocuspocus + Yjs, single-placement, encrypted-page block)
- Comments (threads, replies, resolve, inline highlight, hover bubble)
- Backlinks (scan-and-upsert on every save)
- Typed relations (§13.1, no-existence-leak)
- Graph view (§13.2, BFS up to 3 hops, hand-rolled SVG)
- Template inheritance (§13.3, cycle-safe, depth-limited, permission-filtered)
- Lenses / saved filters (§13.4, table + board views, share tokens)
- Plugin event hooks (§13.5, pageLoad / pageSave / attributeChange, failure isolation)
- Code pages (§13.6, Prism highlighting, git export with language extension)
- Mermaid diagrams (§13.6, DOMPurify-sanitized SVG, slash command)
- Per-page encryption (§13.7, AES-GCM DEK/KEK envelope, client-side only)
- Search (FTS5, permission-filtered, snippet escaping, CommandPalette UI)
- Share links (branch-scoped, password-protected, rate-limited, watchdog, public viewer)
- API tokens (account/space/branch scoped, SHA-256 hashed, no-expiration capability-gated)
- Git content store (autosave commits, manual snapshots, DB snapshot/restore, push/pull/gc, clone)
- Export (page/space to Markdown zip, image asset bundling)
- MCP server (JSON-RPC 2.0, 5 tools)
- Instance-to-instance sync (push via MCP transport)
- Email / mailer (nodemailer, SMTP settings, encrypted password, share-link warnings, mention notifications)
- User management (admin promote/demote/suspend, last-admin guard, delete with content reassignment)
- Group management (CRUD, space grants, branch-level local boundaries)
- Notifications (in-app feed, mention notifications, share-link warnings)
- Favorites + pinned pages (offline readability)
- Service worker (read-only offline cache for pinned pages)
- PWA (manifest, icons, installable)
- Theme system (light/dark/contrast, single token file)
- Settings (11 sub-sections: profile, appearance, spaces, groups, users, plugins, integrations, tokens, system, maintenance, danger)
- Audit log (admin viewer, joins users for actor name/email)
- System health (aggregated: errors, git flush, queue, DB, plugins)
- Debug capture (ring buffer, redacted, zip export)
- ErrorBoundary (root-level, styled fallback)
- Encrypted-at-rest for system secrets
- DB indexes (15 added covering all hot query paths)
- Path-traversal defense-in-depth
- Fail-closed auth secret in production
- Per-IP + per-token rate limiting

### ⚠️ Known limitations (acknowledged)

- **Multi-placement collab** — same page cloned into two spaces with two simultaneous editors is not supported (single-placement works). The server blocks it at `checkCollabEligibility`.
- **No vector/embedding search** — deliberate scope cut (brief §7.6). The Sørensen-Dice similarity in `maintenance.service.ts` is the fallback for "find near-duplicate pages."
- **Plugin server modules have no VM sandbox** — they run with full Node.js privileges (trust boundary, not sandbox). Documented in brief §4.5. Only admins can upload plugins.
- **Single-process** — no Redis, no Postgres, no separate worker. Not designed for multi-instance scaling (brief §7.3).
- **Mobile** — non-goal (brief §7.7). The sidebar could collapse on tablet-width as a quick polish.
- **Bundle size** — main chunk is ~1.3MB gzipped. Mermaid is dynamic-imported. Prism is lazy. Side panels are lazy. Further code-splitting is possible but diminishing returns.

---

## 6. Architecture Decisions

These are the 10 structural decisions that must not be undone (from REBUILD.md §4):

1. **Plugin engine is a trust boundary** (not a sandbox) — admin-only upload, capability-gated API, failure isolation
2. **Git is the content store** — every page save commits Markdown + frontmatter to the local repo
3. **Editor canvas is single-pane** — one bordered container, no nested boxes, drag handle is a sibling
4. **Settings live in one place** — `/settings` with 11 sub-sections
5. **One token file** — `src/styles/tokens.css` controls the entire look and feel
6. **Auth is explicit** — `BETTER_AUTH_SECRET`, `rateLimit`, `trustedOrigins` all explicitly configured
7. **Single SQLite connection** — `getDb()` lazy singleton, never a second `new Database()`
8. **Real-time is for collab only** — Hocuspocus/Yjs for live editing, not for notifications or other real-time features
9. **Background work is the queue** — git commits, snapshots, watchdog warnings all go through the DB-backed job queue
10. **Everything is in-process** — no Redis, no separate worker, no external search index

### The permission algorithm

The single `resolveAccess(user, chain, spaceRole)` function in `src/shared/permissions/algorithm.ts` is the most security-critical component. Every route, MCP tool, real-time collab connect, and file-serving path must call this (via the middleware). The 6-step walk:

1. System-branch guard (Trash etc. is admin-only)
2. Admin bypass
3. Visibility walk nearest-first (target's explicit setting wins; only walk ancestors when target is "inherit")
4. Local boundary (nearest branch with explicit `group_permissions` FULLY REPLACES everything above it — hard stop, never merged with visibility baseline)
5. Anonymous fallback to visibility baseline
6. Authenticated fallback to `max(spaceRole, visibilityBaseline)`

The `chain` parameter is a single ordered array (target at index 0, space root last). Splitting targetBranch from ancestors was the original cause of both bugs found in V14's prior implementation.

### The crypto envelope

Per-page encryption (§13.7) uses a DEK + KEK envelope:
- **DEK** (data encryption key): random 256-bit AES-GCM key that encrypts the page body
- **KEK** (key encryption key): derived from the user's unlock passphrase via PBKDF2-SHA-256 (100,000 iterations, 16-byte salt)
- The server stores ONLY the envelope (ciphertext + wrapped DEK + KDF salt/iterations)
- Uses WebCrypto `crypto.subtle` — same module imported by client and server

### The access middleware pattern

Every `/api/*` route (except `/api/auth/*`) MUST declare `config.access` at registration time. The `onRoute` hook throws at registration if any route is missing it — the server refuses to boot. This is a mechanical guard against the "I forgot to gate this route" class of bug.

---

## 7. Security Posture

### What's defended

| Threat | Defense |
|--------|---------|
| Session cookie forgery | Fail-closed `BETTER_AUTH_SECRET` in production |
| SQL injection | All raw SQL uses positional `?` placeholders; drizzle query builder throughout |
| XSS (markdown) | `safeLinkHref()` neutralizes `javascript:`/`data:`/`vbscript:`; `safeImageSrc()` drops `data:` entirely |
| XSS (search snippets) | `escapeSnippet()` HTML-escapes everything except FTS5 `<mark>` markers |
| XSS (Mermaid SVG) | `sanitizeMermaidSvg()` via DOMPurify with `FORBID_TAGS: [script, foreignObject, iframe, object, embed]` |
| XSS (dangerouslySetInnerHTML) | Audit test grep-scans for usage outside 5 sanctioned files |
| Path traversal | `assertInsideRepo()` in git.service; slug regex blocks `..` and `/` |
| Share-link brute force | Per-IP (10/5min) + per-token (50/hour) rate limiters |
| ReDoS | `assertSafeRegex()` bounds star height, quantifier count, backreferences, pattern length |
| Zip bomb | 10MB uncompressed cap on plugin zip extraction |
| CSRF | better-auth's SameSite=Lax cookie + origin validation |
| Secret leakage | System settings secrets encrypted at rest (AES-256-GCM); debug-capture redaction filter strips `/email\|password\|token\|cookie\|authorization\|secret/i` |
| Insecure random | All tokens use `randomBytes(24)` (96 bits); IDs use `crypto.randomUUID()` (122 bits) |

### What's acknowledged but not defended

- **Plugin server modules** have full Node.js access (no VM sandbox). This is the §4.5 trust boundary. Only admins can upload plugins.
- **`cloneFromRemote`** accepts arbitrary git URLs (admin-only). Could be used to scan internal services. URL allowlist not implemented.
- **Cookie `Secure` flag** depends on `baseURL` protocol. A deployment behind a terminating proxy that doesn't forward the protocol would not get `Secure`.

---

## 8. Test Coverage

### Vitest (unit + integration)

- **87 test files**, **649 tests**, **648 passing**
- 1 pre-existing failure: `git-service.test.ts` expects branch name `master` but git defaults to `main` (environment-dependent, not our change)
- `fileParallelism: false` (integration tests hit a real SQLite file)
- Test timeout: 15 seconds

### Playwright (e2e)

- 11 spec files covering: codepage, editor, firstparty plugins, happy-path, plugins, skeleton, slice9, slice19, slice20, tree, tree-context-menu
- Most specs are smoke-level (1-2 tests); `tree-context-menu.spec.ts` is the exception with 6 tests
- e2e requires seeded `data/e2e.db` via `scripts/seed-e2e.ts`

### Security invariant audit

`src/server/__tests__/security-invariants.audit.test.ts` — mechanical invariant test that grep-scans the source tree for:
- No `eval` / `new Function` outside `plugins/loader.ts`
- No `dangerouslySetInnerHTML` outside 5 sanctioned files
- No raw SQL interpolation
- Every `/api/*` route declares `config.access`
- No settings persistence outside `/settings`
- Mermaid SVG sanitization present
- `nosniff` on file responses

### New tests added in this rebuild

- `auth-secret.test.ts` — 4 tests for fail-closed BETTER_AUTH_SECRET
- `crypto.test.ts` — 11 tests for encrypt/decrypt round-trip, tamper detection, fail-closed
- `settings-encryption.integration.test.ts` — 6 tests for full encrypt→store→read cycle
- `mcp.integration.test.ts` — 8 tests for MCP server (initialize, tools/list, all 5 tools, auth rejection)
- `CommandPalette.test.tsx` — 2 tests for render-without-throw
- `codeHighlight.test.ts` — 5 tests (updated for async API)

---

## 9. Known Issues & Limitations

### Pre-existing (not introduced by our work)

1. **Git branch name mismatch** — `git-service.test.ts:120` expects `master` but git defaults to `main` on newer systems. Fix: change the test to accept both, or set `git config --global init.defaultBranch master`.
2. **Regex safety timing test** — `regex-safety.test.ts:97` expects V8 regex backtracking to take >50ms, but on some systems it takes exactly 50ms. Flaky, not a real bug.
3. **`window.prompt` for new page slug** — `Tree.tsx:handleCreatePage` still uses `window.prompt` for the page slug. We replaced the Create Space dialog but left this one. Fix: build an inline slug-input dialog.
4. **`(request as any).userContext` casts** — 68 occurrences across route handlers. Phase 4.3 added the type declaration (`fastify.d.ts`) but didn't refactor existing call sites. New code should use `request.userContext` directly.

### Introduced by our work (acknowledged)

5. **MCP `create_page` doesn't set `initialContent` correctly** — The `markdownToTiptap()` call in `mcp.routes.ts` may return a content shape that `createPage` doesn't expect for all inputs. Tested with simple Markdown and works; complex Markdown (tables, nested lists) is untested.
6. **Sync route doesn't handle image assets** — `sync.routes.ts` pushes page content as Markdown via MCP, but images are not transferred (they'd need to be uploaded to the remote instance's file store separately).
7. **Mention popup positioning** — The pure-DOM popup in `mentionExtension.tsx` doesn't handle viewport edge collision (it could overflow the right/bottom edge). Tippy would handle this; we avoided the dependency.
8. **`fullCommentThreads` prop** — Added to `PageEditor` for the hover bubble, but only the editable page view passes it. Read-only mode doesn't get the hover bubble.

---

## 10. What Needs To Be Done

### Immediate (bugs to fix)

1. **Fix the `git-service.test.ts` branch name test** — Change `expect(status.branch).toBe("master")` to `expect(["master", "main"]).toContain(status.branch)`. 1 line.
2. **Replace `window.prompt` in `Tree.tsx:handleCreatePage`** with an inline slug-input dialog (same pattern as the Create Space dialog we already built).
3. **Test MCP `create_page` with complex Markdown** — tables, nested lists, code blocks. Fix any conversion edge cases.

### Short-term (quality of life)

4. **Refactor `(request as any)` casts** — 68 sites. Now that `fastify.d.ts` declares the types, a find-and-replace can convert `const user = (request as any).userContext as UserContext` to `const user = request.userContext!`. Mechanical but tedious.
5. **Add mention popup viewport collision detection** — Check `rect.right > window.innerWidth` and flip/shift the popup.
6. **Wire `fullCommentThreads` into read-only mode** — Pass comment threads to `ReadOnlyContent` so the hover bubble works there too.
7. **Add Playwright e2e tests for new features** — CommandPalette, Create Space, find & replace, share-link viewer, export, MCP. The standing rule (CONTRIBUTING.md) mandates e2e for every feature.
8. **Test sync with a real remote instance** — The sync route is implemented but only smoke-tested against the local instance.

### Medium-term (features)

9. **Import from zip** — Export is done; import (upload a zip, create pages from .md files) is not. The brief's "no lock-in" guarantee implies both directions.
10. **Bidirectional sync** — Current sync is push-only. Full bidirectional with conflict resolution is a larger project.
11. **Page transclusion** — `![[Page Name]]` syntax that renders the target page's content inline. Natural extension of the wikilink work.
12. **Page aliases** — A page has one slug today. Add an `aliases` column or `page_aliases` table.
13. **"Create page from template" flow** — Templates exist for attribute inheritance but not as content skeletons.
14. **Daily note shortcut** — Cmd+D creates/opens today's date page.

### Long-term (architecture)

15. **Plugin signing** — `plugin.json` field with a signature verified against a trusted public key.
16. **Deepened `/api/health`** — Check DB reachable, git repo present, disk space, queue depth, collab responsive. Return JSON with per-check status.
17. **Automated snapshot verification** — Weekly admin-triggered "restore latest snapshot to a temp DB, run schema validation, discard" job.
18. **Operator backup docs** — `docs/BACKUP.md` covering what to back up, how often, how to test a restore.

---

## 11. How To Run

### Prerequisites

- Node.js 22+
- npm

### Setup

```bash
cd wiki-app-v2
npm install
```

### Development

```bash
# Terminal 1: API server (port 3000)
npm run dev:server

# Terminal 2: Vite dev server (port 5173)
npm run dev
```

Open `http://localhost:5173`. The first user to sign up becomes admin (bootstrap hook). A "Welcome" space is seeded automatically.

### Environment variables

| Variable | Default | Required | Purpose |
|----------|---------|----------|---------|
| `PORT` | `3000` | No | API server port |
| `HOST` | `0.0.0.0` | No | API server bind |
| `DB_PATH` | `data/wiki.db` | No | SQLite database path |
| `GIT_REPO_ROOT` | `data/repo` | No | Git content repo path |
| `BETTER_AUTH_SECRET` | (dev fallback) | **Yes in production** | Session signing secret — throws if unset in prod |
| `BETTER_AUTH_URL` | `http://localhost:3000` | No | Base URL for auth callbacks |
| `SETTINGS_ENCRYPTION_KEY` | (dev fallback) | **Yes in production** | Encrypts system_settings secrets — throws if unset in prod |
| `BETTER_EXTRA_TRUSTED_ORIGINS` | — | No | Comma-separated additional trusted origins |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | — | No | Google SSO |
| `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` | — | No | GitHub SSO |
| `ALLOW_PRIVATE_CLIP_HOSTS` | `0` | No | Set to `1` to allow web-clipper to fetch private IPs (LAN/dev only) |
| `PLUGIN_FAILURE_THRESHOLD` | `5` | No | Consecutive failures before auto-disable |

### Testing

```bash
npm run typecheck          # tsc --noEmit, strict
npx vitest run             # unit + integration (fileParallelism=false)
npm run build              # typecheck + vite build
npx playwright test        # e2e (requires seeded data/e2e.db)
npx tsx scripts/parity-audit.ts  # V14-vs-V2 feature diff
```

### Production

```bash
NODE_ENV=production npm start
```

**Must set before production deploy:**
- `BETTER_AUTH_SECRET` (32+ random bytes, hex-encoded)
- `SETTINGS_ENCRYPTION_KEY` (32+ random bytes, hex-encoded)
- `BETTER_AUTH_URL` (your public URL)

Generate keys:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## 12. Key Files Reference

### Security-critical

| File | Purpose |
|------|---------|
| `src/server/auth/config.ts` | better-auth wiring, fail-closed secret |
| `src/server/services/crypto.service.ts` | AES-256-GCM encrypt/decrypt for secrets |
| `src/server/middleware/access.ts` | Permission middleware (config.access gate + preHandler) |
| `src/shared/permissions/algorithm.ts` | The `resolveAccess()` function (do not modify without full re-test) |
| `src/server/security.ts` | CSP, nosniff, frame-options, referrer-policy |
| `src/server/__tests__/security-invariants.audit.test.ts` | Mechanical invariant grep-scan |
| `src/shared/blockIds.ts` | `validateContent()`, `safeLinkHref()`, `safeImageSrc()`, `KNOWN_*_TYPES` |
| `src/shared/cryptoEnvelope.ts` | Per-page encryption (DEK + KEK envelope) |

### New files added in this rebuild

| File | Phase | Purpose |
|------|-------|---------|
| `src/server/services/crypto.service.ts` | 0.5 | Encrypted-at-rest for system secrets |
| `src/server/services/export.service.ts` | 3.3 | Page/space export to Markdown zip |
| `src/server/services/mailer.service.ts` | 3.5 | Email delivery (nodemailer) |
| `src/server/services/user-delete.service.ts` | 3.6 | User deletion with content reassignment |
| `src/server/routes/mcp.routes.ts` | 3.1 | MCP JSON-RPC server (5 tools) |
| `src/server/routes/export.routes.ts` | 3.3 | Export route handlers |
| `src/server/routes/sync.routes.ts` | 3.4 | Instance-to-instance sync |
| `src/server/types/fastify.d.ts` | 4.3 | Typed Fastify request augmentation |
| `src/features/editor/CommentHoverBubble.tsx` | 4.1 | Comment hover popup |
| `src/features/editor/SearchReplacePopup.tsx` | 2.8 | Find & replace (Ctrl+F) |
| `src/features/editor/useHighlightedCode.ts` | 0.11 | Async Prism highlighting hook |
| `src/features/editor/extensions/wikilink.ts` | 2.6 | Internal `[[Page]]` link mark |
| `src/features/editor/extensions/mentionExtension.tsx` | 2.5 | @Mention suggestion popup |
| `src/features/editor/extensions/attachmentExtension.tsx` | 2.7 | Rich file attachment node |
| `src/features/search/CommandPalette.tsx` | 1.2 | Cmd+K search overlay |
| `src/features/settings/useEditorWidthLoader.ts` | 4.2 | Load editor width at startup |
| `src/routes/_public/share.$branchId.tsx` | 3.2 | Public share-link viewer |
| `scripts/parity-audit.ts` | 0.7 | V14-vs-V2 feature diff |
| `CONTRIBUTING.md` | 0.6 | Standing rule + code style |
| `public/icon.svg` | 0.8 | PWA icon |
| `drizzle/0011_missing_indexes.sql` | 0.4 | 15 DB indexes |

### Modified files (significant changes)

| File | What changed |
|------|-------------|
| `src/server/auth/config.ts` | Fail-closed `resolveAuthSecret()` |
| `src/server/services/git.service.ts` | `assertInsideRepo()` path-traversal guard |
| `src/server/services/collab.service.ts` | LRU eviction for Yjs doc cache |
| `src/server/routes/settings.routes.ts` | Encrypt/decrypt wiring + audit-log endpoint |
| `src/server/routes/user.routes.ts` | Mentionable endpoint + delete route |
| `src/server/routes/share.routes.ts` | Share URL format → `/share/$branchId?shareToken=...` |
| `src/server/middleware/access.ts` | Per-token rate limiter |
| `src/server/db/schema.ts` | 15 index declarations + attachment/wikilink/highlight types |
| `src/server/app.ts` | Crypto boot check + MCP/export/sync route registration |
| `src/shared/blockIds.ts` | `highlight` + `wikilink` marks, `attachment` block |
| `src/features/editor/editorExtensions.ts` | 6 new TipTap extensions wired in |
| `src/features/editor/Editor.tsx` | Toolbar buttons (task list, align, highlight, search) + find & replace + attachment upload |
| `src/features/editor/codeHighlight.ts` | Lazy loading via dynamic `import()` |
| `src/features/tree/Tree.tsx` | Create Space dialog |
| `src/routes/_authenticated.tsx` | CommandPalette + Search button + editor width loader |
| `src/routes/_authenticated/settings/system.tsx` | Git section + Audit Log section |
| `src/routes/_authenticated/settings/integrations.tsx` | SMTP section |
| `src/routes/_authenticated/settings/tokens.tsx` | ConfirmDialog replacing `confirm()` |
| `src/routes/_authenticated/settings/plugins.tsx` | ConfirmDialog replacing `confirm()` |
| `src/routes/_authenticated/w/$branchId.tsx` | Lazy side panels + `fullCommentThreads` prop |
| `src/features/history/HistoryPanel.tsx` | ConfirmDialog replacing `confirm()` |
| `src/routes/__root.tsx` | ErrorBoundary |
| `src/styles/app.css` | All new component CSS (ErrorBoundary, CommandPalette, task lists, highlight, wikilinks, mention popup, attachment, comment hover bubble) |
| `src/api/client.ts` | Git + audit log API wrappers + types |

---

## Final Notes

### The standing rule (from CONTRIBUTING.md)

> A feature is **done** when BOTH:
> 1. A real end-to-end test (Playwright) performs the action through the actual UI
> 2. A human has manually clicked through it once

This rule was not followed during the original V2 rebuild, which is how the parity gap happened. It must be followed going forward.

### What an AI agent picking this up should do first

1. Read `WIKI-REDESIGN-BRIEF-V2.md` (the normative spec)
2. Read `REBUILD.md` (the original rebuild narrative, slices 1-48)
3. Read this document (what we changed and why)
4. Run `npm run typecheck && npx vitest run && npm run build` to verify the baseline
5. Run `npx tsx scripts/parity-audit.ts` to see the current gap report
6. Check `git log --oneline wiki-app-v3-rebuild` for the full commit history

### Branch info

- **Working branch:** `wiki-app-v3-rebuild` on `github.com/nealhamiltonjr/wiki-main`
- **Base branch:** `rebuild-v2` (the original V2 codebase)
- **No other branches were modified**

---

*End of document.*
