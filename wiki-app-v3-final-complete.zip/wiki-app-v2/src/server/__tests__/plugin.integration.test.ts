import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { randomBytes } from "node:crypto";
import { readFileSync, rmSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { FastifyInstance } from "fastify";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const DB_PATH = `data/test-plugin-${randomBytes(4).toString("hex")}.db`;
const REPO_PATH = `data/test-plugin-repo-${randomBytes(4).toString("hex")}`;

process.env.DB_PATH = DB_PATH;
process.env.GIT_REPO_ROOT = REPO_PATH;
process.env.BETTER_AUTH_SECRET = "test-only-secret-do-not-use-in-real-deployment-aaaaaaaaaaaaaaaa";
process.env.BETTER_AUTH_URL = "http://localhost:3000";
process.env.BETTER_AUTH_RATE_LIMIT_CUSTOM_RULES = JSON.stringify({
  "/sign-up/*": false,
  "/sign-in/*": false,
});

let app: FastifyInstance;

function extractCookie(setCookieHeader: string | string[] | undefined): string {
  const raw = Array.isArray(setCookieHeader) ? setCookieHeader[0] : setCookieHeader;
  const cookie = raw?.split(";")[0] ?? "";
  return cookie;
}

describe("plugin engine (slice-12) integration", () => {
  let adminCookie: string;

  beforeAll(async () => {
    const { buildApp } = await import("../app.js");
    app = await buildApp();
    await app.ready();

    // Sign up an admin user through the real auth flow.
    const signupRes = await app.inject({
      method: "POST",
      url: "/api/auth/sign-up/email",
      payload: { email: "admin@test.invalid", password: "testtest1234", name: "Admin" },
    });
    if (signupRes.statusCode !== 200) {
      // User may already exist (collab test ran first); try sign-in.
      const signinRes = await app.inject({
        method: "POST",
        url: "/api/auth/sign-in/email",
        payload: { email: "admin@test.invalid", password: "testtest1234" },
      });
      expect(signinRes.statusCode).toBe(200);
      adminCookie = extractCookie(signinRes.headers["set-cookie"]);
      expect(adminCookie).toBeTruthy();
    } else {
      adminCookie = extractCookie(signupRes.headers["set-cookie"]);
      expect(adminCookie).toBeTruthy();
    }

    // The plugin upload routes are global-admin-only (config.access: "admin"),
    // and signup can never create a global admin (isAdmin is input:false on the
    // public auth API). Promote the test user directly in the DB — the access
    // middleware reads isAdmin fresh per request, so the existing session picks
    // it up immediately.
    const { getDb } = await import("../db/index.js");
    const { users } = await import("../db/schema.js");
    const { eq } = await import("drizzle-orm");
    await getDb().db.update(users).set({ isAdmin: true }).where(eq(users.email, "admin@test.invalid"));
  });

  afterAll(async () => {
    await app.close();
    const pluginDir = path.resolve(__dirname, "../../../data/plugins/hello-world");
    rmSync(pluginDir, { recursive: true, force: true });
  });

  it("returns 401 for unauthenticated plugin list", async () => {
    const res = await app.inject({ method: "GET", url: "/api/plugins" });
    expect(res.statusCode).toBe(401);
  });

  it("returns empty plugin list for authenticated non-admin", async () => {
    const res = await app.inject({ method: "GET", url: "/api/plugins", headers: { cookie: adminCookie } });
    expect(res.statusCode).toBe(200);
    const list = JSON.parse(res.payload) as unknown[];
    // Non-admin sees only enabled; initially none.
    expect(Array.isArray(list)).toBe(true);
  });

  it("plugin upload returns 415 for non-multipart body", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/api/plugins",
      headers: { "content-type": "application/zip", cookie: adminCookie },
      payload: Buffer.from("fake"),
    });
    // No multipart boundary → fastify-multipart returns 415 as the body
    // can't be parsed as multipart.
    expect(res.statusCode).toBe(415);
  });

  it("installs the hello-world fixture zip end-to-end", async () => {
    const zipPath = path.resolve(__dirname, "../../../test-fixtures/hello-world-plugin.zip");
    const zipData = readFileSync(zipPath);
    const boundary = `----test-${randomBytes(4).toString("hex")}`;

    const res = await app.inject({
      method: "POST",
      url: "/api/plugins",
      headers: { cookie: adminCookie, "content-type": `multipart/form-data; boundary=${boundary}` },
      payload: Buffer.concat([
        Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="hello-world-plugin.zip"\r\nContent-Type: application/zip\r\n\r\n`),
        zipData,
        Buffer.from(`\r\n--${boundary}--\r\n`),
      ]),
    });

    expect(res.statusCode).toBe(201);
    const info = JSON.parse(res.payload) as {
      id: string; name: string; version: string; enabled: boolean; nodeTypes: string[];
    };
    expect(info.id).toBe("hello-world");
    expect(info.name).toBe("Hello World Plugin");
    expect(info.version).toBe("1.0.0");
    expect(info.enabled).toBe(false);
    // The manifest's content model drives what validateContent accepts.
    expect(info.nodeTypes).toContain("helloWorld");

    // The zip's files must be on disk at the expected locations.
    const pluginDir = path.resolve(__dirname, "../../../data/plugins/hello-world");
    expect(readFileSync(path.join(pluginDir, "plugin.json"), "utf-8")).toContain('"hello-world"');
    expect(readFileSync(path.join(pluginDir, "client/index.js"), "utf-8")).toContain("HelloWorldNode");
    expect(readFileSync(path.join(pluginDir, "server/index.js"), "utf-8")).toContain("helloWorldPlugin");
  });

  it("enabling a serverRoutes-only plugin does not load it as a hook module (regression)", async () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      const { totalHookSubscriptionCount } = await import("../hooks.js");
      const before = totalHookSubscriptionCount();

      const res = await app.inject({
        method: "PUT",
        url: "/api/plugins/hello-world/enabled",
        headers: { cookie: adminCookie },
        payload: { enabled: true },
      });
      expect(res.statusCode).toBe(200);

      // hello-world declares serverRoutes, not hooks — it must NOT be imported
      // through the hook-module path (which would call its Fastify plugin with
      // a bare {registerHook} API and throw "app.get is not a function").
      expect(errorSpy).not.toHaveBeenCalledWith(
        expect.stringContaining('[hooks] Failed to load hook handlers for plugin "hello-world"'),
        expect.anything(),
      );
      expect(totalHookSubscriptionCount()).toBe(before);
    } finally {
      errorSpy.mockRestore();
    }
  });

  it("rejects a second install of the same plugin id", async () => {
    const zipPath = path.resolve(__dirname, "../../../test-fixtures/hello-world-plugin.zip");
    const zipData = readFileSync(zipPath);
    const boundary = `----test-${randomBytes(4).toString("hex")}`;

    const res = await app.inject({
      method: "POST",
      url: "/api/plugins",
      headers: { cookie: adminCookie, "content-type": `multipart/form-data; boundary=${boundary}` },
      payload: Buffer.concat([
        Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="hello-world-plugin.zip"\r\nContent-Type: application/zip\r\n\r\n`),
        zipData,
        Buffer.from(`\r\n--${boundary}--\r\n`),
      ]),
    });

    expect(res.statusCode).toBe(409);
    expect(res.payload).toContain("already installed");
  });

  it("only one of two concurrent installs of the same id succeeds (UNIQUE-constraint race guard)", async () => {
    // The earlier existence-check version had a window where two admins
    // uploading the same zip could both pass the existence check, race the
    // filesystem rename, and leave one with an inconsistent on-disk state.
    // The fix inserts the DB row first; the UNIQUE constraint serializes
    // everyone onto a single winner.
    const zipPath = path.resolve(__dirname, "../../../test-fixtures/hello-world-plugin.zip");
    const zipData = readFileSync(zipPath);

    async function postInstall(): Promise<{ status: number; body: string }> {
      const boundary = `----test-${randomBytes(4).toString("hex")}`;
      const res = await app.inject({
        method: "POST",
        url: "/api/plugins",
        headers: { cookie: adminCookie, "content-type": `multipart/form-data; boundary=${boundary}` },
        payload: Buffer.concat([
          Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="hello-world-plugin.zip"\r\nContent-Type: application/zip\r\n\r\n`),
          zipData,
          Buffer.from(`\r\n--${boundary}--\r\n`),
        ]),
      });
      return { status: res.statusCode, body: res.payload };
    }

    // The hello-world plugin was already installed by the first test in this
    // suite, so BOTH installs in this race should be 409 — we're proving that
    // the gate is consistent under concurrency, not that anything gets
    // installed here. The first 409 had to come from the DB UNIQUE
    // constraint (re-thrown as 409), since the second arrival can't have
    // found a row with an existence check done mid-flight on the first.
    const [a, b] = await Promise.all([postInstall(), postInstall()]);
    const statuses = [a.status, b.status].sort();
    expect(statuses).toEqual([409, 409]);
    expect(a.body).toContain("already installed");
    expect(b.body).toContain("already installed");

    // Sanity: exactly one row exists for "hello-world" (the one from the
    // first test), and the on-disk plugin directory is intact.
    const list = await app.inject({
      method: "GET",
      url: "/api/plugins",
      headers: { cookie: adminCookie },
    });
    const plugins = (list.json() as Array<{ id: string; version: string }>).filter((p) => p.id === "hello-world");
    expect(plugins.length).toBe(1);
    expect(plugins[0]!.version).toBe("1.0.0");
  });

  it("content validation accepts plugin node types via extra options", async () => {
    const { validateContent } = await import("../../shared/blockIds.js");
    const extraNodes = new Set(["helloWorld"]);
    const extraMarks = new Set<string>();

    const { errors } = validateContent(
      { type: "doc", content: [{ type: "helloWorld", attrs: { message: "hi" } }] },
      { extraNodeTypes: extraNodes, extraMarkTypes: extraMarks },
    );
    expect(errors.filter(e => e.includes("unknown node type"))).toHaveLength(0);
  });

  it("rejects unknown plugin node types without extra options", async () => {
    const { validateContent } = await import("../../shared/blockIds.js");
    const { errors } = validateContent(
      { type: "doc", content: [{ type: "helloWorld", attrs: { message: "hi" } }] },
    );
    expect(errors.some(e => e.includes("unknown node type"))).toBe(true);
  });
});

